import 'package:hive/hive.dart';
import '../models/song_model.dart';
import '../services/song_service.dart';

class SongRepository {
  final SongService service;
  final Box songBox = Hive.box("songsBox");

  SongRepository(this.service);

  Future<List<SongModel>> getSongs() async {
    // 1. Load from Hive cache
    final cached = songBox.values
        .map((json) => SongModel.fromJson(Map<String, dynamic>.from(json)))
        .toList();

    if (cached.isNotEmpty) {
      // fetch fresh in background
      fetchAndCacheSongs();
      return cached;
    }

    // 2. If no cache → fetch directly
    return await fetchAndCacheSongs();
  }

  Future<List<SongModel>> fetchAndCacheSongs() async {
    final songs = await service.fetchSongs();
    // Save to Hive
    for (var song in songs) {
      songBox.put(song.id, song.toJson());
    }
    return songs;
  }
}
