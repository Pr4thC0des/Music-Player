import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import '../providers/player_provider.dart';
import '../widgets/player_controls.dart';
import '../widgets/progress_bar.dart';

class PlayerScreen extends ConsumerWidget {
  const PlayerScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final currentSong = ref.watch(playerProvider);

    if (currentSong == null) {
      return const Scaffold(
        body: Center(child: Text("No song playing")),
      );
    }

    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.black),
          onPressed: () {
            // 👉 Going back shows Mini Player (will handle in mini_player.dart)
            Navigator.pop(context);
          },
        ),
      ),
      body: Padding(
        padding: EdgeInsets.all(20.w),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            // 🎵 Album Art
            ClipRRect(
              borderRadius: BorderRadius.circular(20.r),
              child: Image.network(
                currentSong.media,
                width: double.infinity,
                height: 300.h,
                fit: BoxFit.cover,
              ),
            ),
            SizedBox(height: 20.h),

            // 🎶 Song Info
            Column(
              children: [
                Text(
                  currentSong.title,
                  style: TextStyle(fontSize: 20.sp, fontWeight: FontWeight.bold),
                  textAlign: TextAlign.center,
                ),
                SizedBox(height: 6.h),
                Text(
                  currentSong.artist,
                  style: TextStyle(fontSize: 16.sp, color: Colors.grey),
                  textAlign: TextAlign.center,
                ),
              ],
            ),

            // 📊 Progress Bar
            const ProgressBarWidget(),

            // 🎛 Controls
            const PlayerControls(),
          ],
        ),
      ),
    );
  }
}
