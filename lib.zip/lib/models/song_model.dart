import 'package:hive/hive.dart';

part 'song_model.g.dart';

@HiveType(typeId: 0)
class SongModel extends HiveObject {
  @HiveField(0)
  final int id;

  @HiveField(1)
  final String title;

  @HiveField(2)
  final String artist;

  @HiveField(3)
  final String media;

  @HiveField(4)
  final String streamUrl;

  @HiveField(5)
  final int? duration;

  SongModel({
    required this.id,
    required this.title,
    required this.artist,
    required this.media,
    required this.streamUrl,
    this.duration,
  });

  factory SongModel.fromJson(Map<String, dynamic> json) {
    return SongModel(
      id: json["id"],
      title: json["title"],
      artist: json["artist"],
      media: json["media"],
      streamUrl: json["stream_url"],
      duration: json["duration"],
    );
  }

  Map<String, dynamic> toJson() {
    return {
      "id": id,
      "title": title,
      "artist": artist,
      "media": media,
      "stream_url": streamUrl,
      "duration": duration,
    };
  }

  SongModel copyWith({int? duration}) {
    return SongModel(
      id: id,
      title: title,
      artist: artist,
      media: media,
      streamUrl: streamUrl,
      duration: duration ?? this.duration,
    );
  }
}
