import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import '../models/song_model.dart';
import '../providers/player_provider.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

class SongTile extends ConsumerWidget {
  final SongModel song;
  final int index;
  final List<SongModel> playlist;

  const SongTile({
    super.key,
    required this.song,
    required this.index,
    required this.playlist,
  });

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final playerNotifier = ref.read(playerProvider.notifier);

    return Card(
      margin: EdgeInsets.symmetric(vertical: 8.h),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12.r)),
      elevation: 3,
      child: ListTile(
        contentPadding: EdgeInsets.all(12.w),
        leading: ClipRRect(
          borderRadius: BorderRadius.circular(8.r),
          child: Image.network(
            song.media,
            width: 60.w,
            height: 60.w,
            fit: BoxFit.cover,
          ),
        ),
        title: Text(
          song.title,
          style: TextStyle(fontSize: 16.sp, fontWeight: FontWeight.bold),
          overflow: TextOverflow.ellipsis,
        ),
        subtitle: Text(
          song.artist,
          style: TextStyle(fontSize: 14.sp, color: Colors.grey[600]),
          overflow: TextOverflow.ellipsis,
        ),
        trailing: Text(
          song.duration != null
              ? "${(song.duration! ~/ 60)}:${(song.duration! % 60).toString().padLeft(2, '0')}"
              : "--:--",
          style: TextStyle(fontSize: 14.sp, fontWeight: FontWeight.w500),
        ),
        onTap: () async {
          // 👉 Start playback from selected song
          await playerNotifier.setPlaylist(playlist, index);

          // 👉 Navigate to full player screen
          Navigator.pushNamed(context, "/player");
        },
      ),
    );
  }
}
