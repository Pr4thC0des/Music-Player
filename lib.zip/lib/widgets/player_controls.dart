import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../providers/player_provider.dart';

class PlayerControls extends ConsumerWidget {
  const PlayerControls({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final playerNotifier = ref.read(playerProvider.notifier);
    final currentSong = ref.watch(playerProvider);

    // Get playing state from AudioPlayer (via playerNotifier.player)
    final isPlaying = playerNotifier.player.playing;

    if (currentSong == null) {
      return const SizedBox.shrink();
    }

    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
      children: [
        IconButton(
          icon: const Icon(Icons.skip_previous, size: 32),
          onPressed: () => playerNotifier.previous(),
        ),
        IconButton(
          icon: Icon(
            isPlaying ? Icons.pause_circle : Icons.play_circle,
            size: 48,
          ),
          onPressed: () => playerNotifier.playPause(),
        ),
        IconButton(
          icon: const Icon(Icons.skip_next, size: 32),
          onPressed: () => playerNotifier.next(),
        ),
        IconButton(
          icon: const Icon(Icons.volume_up, size: 28),
          onPressed: () => playerNotifier.muteUnmute(),
        ),
        IconButton(
          icon: const Icon(Icons.queue_music, size: 28),
          onPressed: () {
            Navigator.pop(context); // back to Playlist / MiniPlayer
          },
        ),
      ],
    );
  }
}
