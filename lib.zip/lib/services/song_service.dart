import 'dart:convert';
import 'package:http/http.dart' as http;
import '../models/song_model.dart';

class SongService {
  static const String baseUrl = "http://templerun.click/api/song/";

  Future<List<SongModel>> fetchSongs() async {
    final url = Uri.parse("${baseUrl}songs/");
    print("🔎 Fetching songs from $url");

    final response = await http.get(url);

    print("🔎 Response status: ${response.statusCode}");
    print("🔎 Response body: ${response.body}");

    if (response.statusCode == 200) {
      final List data = json.decode(response.body);

      if (data.isNotEmpty) {
        print("🔎 First song object: ${data.first}");
      }

      return data.map((json) => SongModel.fromJson(json)).toList();
    } else {
      throw Exception("Failed to load songs: ${response.statusCode}");
    }
  }
}
