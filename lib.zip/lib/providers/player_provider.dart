import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:just_audio/just_audio.dart';
import '../models/song_model.dart';

final audioPlayerProvider = Provider<AudioPlayer>((ref) {
  final player = AudioPlayer();
  ref.onDispose(() => player.dispose());
  return player;
});

class PlayerNotifier extends StateNotifier<SongModel?> {
  final AudioPlayer player;
  List<SongModel> playlist = [];
  int currentIndex = 0;

  PlayerNotifier(this.player) : super(null);

  Future<void> setPlaylist(List<SongModel> songs, int startIndex) async {
    playlist = songs;
    currentIndex = startIndex;
    await playSong(playlist[currentIndex]);
  }

  Future<void> playSong(SongModel song) async {
    state = song;
    await player.setUrl(song.streamUrl);
    player.play();
  }

  void playPause() {
    if (player.playing) {
      player.pause();
    } else {
      player.play();
    }
  }

  Future<void> next() async {
    if (currentIndex < playlist.length - 1) {
      currentIndex++;
      await playSong(playlist[currentIndex]);
    }
  }

  Future<void> previous() async {
    if (currentIndex > 0) {
      currentIndex--;
      await playSong(playlist[currentIndex]);
    }
  }

  void muteUnmute() {
    if (player.volume > 0) {
      player.setVolume(0);
    } else {
      player.setVolume(1);
    }
  }
}

final playerProvider =
    StateNotifierProvider<PlayerNotifier, SongModel?>((ref) {
  final player = ref.read(audioPlayerProvider);
  return PlayerNotifier(player);
});
