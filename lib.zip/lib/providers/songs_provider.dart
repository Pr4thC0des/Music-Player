import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../models/song_model.dart';
import '../repositories/song_repository.dart';
import '../services/song_service.dart';

final songServiceProvider = Provider((ref) => SongService());
final songRepositoryProvider = Provider(
  (ref) => SongRepository(ref.read(songServiceProvider)),
);

final songsProvider = FutureProvider<List<SongModel>>((ref) async {
  final repo = ref.read(songRepositoryProvider);
  return await repo.getSongs();
});
